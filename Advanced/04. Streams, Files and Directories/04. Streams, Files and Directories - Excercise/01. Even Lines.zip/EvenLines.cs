﻿namespace EvenLines
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class EvenLines
    {
        static void Main(string[] args)
        {
            string inputFilePath = @"..\..\..\text.txt";

            Console.WriteLine(ProcessLines(inputFilePath).TrimEnd());
        }

        public static string ProcessLines(string inputFilePath)
        {
            int n = 0;
            string text = "";
            var list = new List<string>();

            using (var sr = new StreamReader(inputFilePath))
            {
                string line = sr.ReadLine();

                while (line != null)
                {
                    if(n % 2 == 0)
                        list.Add(ReplaceSymbols(line));

                    n++;
                    line = sr.ReadLine();
                }
            }

            foreach (var line in list)
                text += ReverseWords(line) + "\n";

            return text;
        }
        private static string ReverseWords(string replacedSymbols)
        {
            List<string> words = replacedSymbols.Split(' ').ToList();

            string line = "";

            for (int i = words.Count - 1; i >= 0; i--)
                line += words[i] + " ";

            return line;
        }

        private static string ReplaceSymbols(string line)
        {
            foreach (var ch in line)
            {
                if (ch == '-' || ch == ',' || ch == '.' || ch == ',' || ch == '!' || ch == '?')
                    line = line.Replace(ch, '@');
            }

            return line;
        }
    }

}
