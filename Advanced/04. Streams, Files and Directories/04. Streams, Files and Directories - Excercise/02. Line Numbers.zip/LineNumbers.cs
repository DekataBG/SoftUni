﻿namespace LineNumbers
{
    using System;
    using System.IO;

    public class LineNumbers
    {
        static void Main(string[] args)
        {
            string inputPath = @"..\..\..\text.txt";
            string outputPath = @"..\..\..\output.txt";

            ProcessLines(inputPath, outputPath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] textFromFile = File.ReadAllLines(inputFilePath);
            string[] textForFile = new string[textFromFile.Length];

            for (int i = 0; i < textFromFile.Length; i++)
            {
                int punctuation = 0, letters = 0;

                foreach (var ch in textFromFile[i])
                {
                    if (char.IsLetterOrDigit(ch))
                        letters++;
                    else if(!char.IsLetterOrDigit(ch) && ch != ' ')
                        punctuation++;
                }

                textForFile[i] = $"Line {i + 1}: " + textFromFile[i] + $"({letters})({punctuation})";
            }

            File.WriteAllLines(outputFilePath, textForFile);
        }
    }
}
