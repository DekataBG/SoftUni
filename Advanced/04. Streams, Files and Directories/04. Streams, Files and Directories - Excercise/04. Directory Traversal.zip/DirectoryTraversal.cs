﻿namespace DirectoryTraversal
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class DirectoryTraversal
    {
        static void Main(string[] args)
        {
            string path = Console.ReadLine();
            string reportFileName = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) +
                @"\report.txt";

            string reportContent = TraverseDirectory(path);

            WriteReportToDesktop(reportContent, reportFileName);
        }

        public static string TraverseDirectory(string inputFolderPath)
        {
            string output = "";
            var directoryInfo = new DirectoryInfo(inputFolderPath);
            var files = directoryInfo.GetFiles();
            var filesExtensions = new Dictionary<FileInfo, string>();
            var extensions = new Dictionary<string, List<FileInfo>>();

            for (int i = 0; i < files.Length; i++)
            {
                string fileName = files[i].Name;
                string extension = fileName.Substring(fileName.LastIndexOf('.'));
                filesExtensions.Add(files[i], extension);
            }

            foreach (var pair in filesExtensions)
                extensions = AddValue(extensions, pair.Value, pair.Key);

            extensions = extensions.OrderByDescending(c => c.Value.Count)
                                    .ToDictionary(x => x.Key, x => x.Value);

            foreach (var item in extensions)
            {
                output += item.Key + "\n";
                foreach (var file in extensions[item.Key])
                    output += $"--{file.Name} - {String.Format("{0:0.000}", (double)file.Length / 1000)}kb\n"; 
            }
            return output.TrimEnd();
        }

        public static void WriteReportToDesktop(string textContent, string reportFileName)
        {
            using var writer = new StreamWriter(reportFileName);
            writer.Write(textContent);
        }
        public static Dictionary<string, List<FileInfo>> AddValue(Dictionary<string, List<FileInfo>> dict, 
                                                                string key, FileInfo value)
        {
            if(dict.ContainsKey(key))
                dict[key].Add(value);
            else
                dict.Add(key, new List<FileInfo>() { value });

            for (int i = 0; i < dict.Count; i++)
            {
                foreach (var item in dict)
                {
                    dict[item.Key] = dict[item.Key].OrderBy(s => s.Length).ToList();
                    break;
                }
            }
            return dict;
        }
    }
}
