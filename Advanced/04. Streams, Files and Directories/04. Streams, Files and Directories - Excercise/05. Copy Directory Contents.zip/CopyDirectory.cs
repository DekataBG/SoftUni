﻿namespace CopyDirectory
{
    using System;
    using System.IO;

    public class CopyDirectory
    {
        static void Main(string[] args)
        {
            //C:\Users\DELL\Desktop\daskalo\pictures
            string inputPath = Console.ReadLine();

            //C:\Users\DELL\Desktop\daskalo\pictures1
            string outputPath = Console.ReadLine();

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            var dirInput = new DirectoryInfo(inputPath);
            var dirOutput = new DirectoryInfo(outputPath);


            if (dirOutput.Exists)
                dirOutput.Delete(true);
            
                dirOutput.Create();

            foreach (var file in dirInput.GetFiles())
                file.CopyTo(outputPath + "/" + file.Name);
        }
    }
}
