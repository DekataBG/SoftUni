﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ConsoleTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var list = new ListyIterator<string>();
            var initialCommand = Console.ReadLine();
            string name = null;

            if (initialCommand.Contains(' '))
                name = initialCommand.Substring(initialCommand.IndexOf(' ') + 1);
            list.Create(name);

            string command = Console.ReadLine();
            while (command != "END")
            {
                switch (command)
                {
                    case "Move":
                        Console.WriteLine(list.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(list.HasNext());
                        break;
                    case "Print":
                        list.Print();
                        break;
                }

                command = Console.ReadLine();
            }

        }
    }
    public class ListyIterator<T> where T : class
    {
        private int index;
        public ListyIterator()
        {
            index = 0;
            List = new List<T>();
        }
        public List<T> List { get; set; }
        public bool Move()
        {
            if (index == List.Count - 1)
                return false;

            index++;
            return true;
        }
        public bool HasNext()
        {
            if (index == List.Count - 1)
                return false;

            return true;
        }
        public void Print()
        {
            if (List.Count > 0)
                Console.WriteLine(List[index]);
            else
                Console.WriteLine("Invalid Operation!");
        }
        public void Create(string str)
        {
            if (str == null)
                return;
            else
            {
                var elements = str.Split();

                foreach (var item in elements)
                {
                    if (item != null)
                        List.Add(item as T);
                }
            }
        }
    }
}
