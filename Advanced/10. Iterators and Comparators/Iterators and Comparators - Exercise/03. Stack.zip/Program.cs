﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ConsoleTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var stack = new CustomStack<int>();
            string command = Console.ReadLine();

            while (command != "END")
            {
                if (command.Contains("Push"))
                {
                    var subCommand = command.Substring(command.IndexOf(' ') + 1);
                    var items = subCommand.Split(", ").Select(int.Parse);

                    foreach (var item in items)
                        stack.Push(item);

                }
                else
                {
                    try
                    {
                        stack.Pop();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("No elements");
                    }
                }

                command = Console.ReadLine();
            }

            foreach (var item in stack)
            {
                Console.WriteLine(item);
            }
            foreach (var item in stack)
            {
                Console.WriteLine(item);
            }
        }
    }
    public class CustomStack<T> : IEnumerable<T>
    {
        private T[] items = new T[1];
        private int count;
        public void Push(T element)
        {
            if (count == items.Length)
            {
                var newArr = new T[items.Length * 2];
                items.CopyTo(newArr, 0);
                newArr[count] = element;
                items = newArr;
                count++;
            }
            else
            {
                items[count] = element;
                count++;
            }
        }
        public T Pop()
        {
            var element = items[count - 1];

            count--;

            return element;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = count - 1; i >= 0; i--)
            {
                yield return items[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
