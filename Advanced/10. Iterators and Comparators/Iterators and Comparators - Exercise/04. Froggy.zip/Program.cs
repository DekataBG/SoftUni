﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ConsoleTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var numbers = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();

            var lake = new Lake(numbers);

            Console.WriteLine(String.Join(", ", lake));
        }
    }
    public class Lake : IEnumerable<int>
    {
        private int[] numbers;
        public Lake(int[] numbers)
        {
            this.numbers = numbers;
        }
        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < numbers.Length; i += 2)
            {
                yield return numbers[i];
            }
            for (int i = numbers.Length - 1; i >= 1; i--)
            {
                if (i % 2 == 1)
                    yield return numbers[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
