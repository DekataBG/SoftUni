﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ConsoleTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var list = new List<Person>();

            string[] command = Console.ReadLine().Split();

            while (command[0] != "END")
            {
                list.Add(new Person(command[0], int.Parse(command[1]), command[2]));

                command = Console.ReadLine().Split();
            }

            int index = int.Parse(Console.ReadLine()) - 1;

            int same = 0, different = 0;
            foreach (var item in list)
            {
                if (item.CompareTo(list[index]) == 0)
                    same++;
                else
                    different++;
            }

            if (same > 1)
                Console.WriteLine($"{same} {different} {same + different}");
            else
                Console.WriteLine("No matches");
        }
    }
    public class Person : IComparable<Person>
    {
        public Person(string name, int age, string town)
        {
            Name = name;
            Age = age;
            Town = town;
        }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Town { get; set; }

        public int CompareTo(Person other)
        {
            if (Name.CompareTo(other.Name) != 0)
                return Name.CompareTo(other.Name);

            if (Age.CompareTo(other.Age) != 0)
                return Age.CompareTo(other.Age);

            if (Town.CompareTo(other.Town) != 0)
                return Town.CompareTo(other.Town);

            return 0;
        }
    }
}
