﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ConsoleTest
{
    public class Person : IComparable<Person>
    {
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }
        public string Name { get; set; }
        public int Age { get; set; }

        public int CompareTo(Person other)
        {
            var result = Name.CompareTo(other.Name);

            if (result == 0)
                return Age - other.Age;

            return result;
        }

        public override bool Equals(object obj)
        {
            var person = obj as Person;

            return person.Name == Name && person.Age == Age;
        }
        public override int GetHashCode()
        {
            return Name.GetHashCode() + Age.GetHashCode();
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            var set = new HashSet<Person>();
            var sortedSet = new SortedSet<Person>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var person = Console.ReadLine().Split(" ");

                set.Add(new Person(person[0], int.Parse(person[1])));
                sortedSet.Add(new Person(person[0], int.Parse(person[1])));

            }

            Console.WriteLine(set.Count);
            Console.WriteLine(sortedSet.Count);
        }
    }
}
