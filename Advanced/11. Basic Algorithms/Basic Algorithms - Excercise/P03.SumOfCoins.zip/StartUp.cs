﻿namespace SumOfCoins
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var totalUsedCoins = 0;

            var coins = Console.ReadLine().Split(", ").Select(int.Parse).OrderByDescending(c => c).ToList();
            var value = int.Parse(Console.ReadLine());

            var usedCoins = ChooseCoins(coins, value);

            try
            {
                if (usedCoins != null)
                {
                    foreach (var item in usedCoins.Values)
                    {
                        totalUsedCoins += item;
                    }
                    Console.WriteLine($"Number of coins to take: {totalUsedCoins}");

                    foreach (var item in usedCoins)
                    {
                        if (item.Value != 0)
                            Console.WriteLine($"{item.Value} coin(s) with value {item.Key}");
                    }
                }
                else
                    int.Parse("@");
            }
            catch (Exception)
            {
                throw new InvalidOperationException();
            }

        }

        public static Dictionary<int, int> ChooseCoins(IList<int> coins, int targetSum)
        {
            var usedCoins = new Dictionary<int, int>();

            foreach (var coin in coins)
            {
                var count = targetSum / coin;

                usedCoins.Add(coin, count);
                targetSum -= coin * count;
            }

            if (targetSum != 0)
                return null;

            return usedCoins;
        }
    }
}