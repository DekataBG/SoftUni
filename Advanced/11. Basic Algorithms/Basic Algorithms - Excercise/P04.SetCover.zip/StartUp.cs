﻿namespace SetCover
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class StartUp
    {
        static void Main(string[] args)
        {
            var universe = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            var n = int.Parse(Console.ReadLine());
            var sets = new List<int[]>();

            for (int i = 0; i < n; i++)
            {
                sets.Add(Console.ReadLine().Split(", ").Select(int.Parse).ToArray());
            }

            var newSets = ChooseSets(sets, universe).ToList();

            Console.WriteLine($"Sets to take ({newSets.Count}):");

            foreach (var item in newSets)
            {
                Console.WriteLine("{ " + String.Join(", ", item) + " }");
            }
        }

        public static List<int[]> ChooseSets(IList<int[]> sets, IList<int> universe)
        {
            var newSets = new List<int[]>();
            var uni = universe.ToList();

            while (uni.Count > 0)
            {
                int max = int.MinValue;
                var maxSet = sets[0];
                foreach (var set in sets)
                {
                    var commonDigits = set.Intersect(uni).Count();
                    if (max < commonDigits)
                    {
                        max = commonDigits;
                        maxSet = set;
                    }
                }

                foreach (var item in maxSet)
                {
                    uni.Remove(item);
                }

                newSets.Add(maxSet);
            }

            return newSets;
        }
    }
}
