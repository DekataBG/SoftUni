﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using CarDealer.DTO;
using CarDealer.DTO.ExportDto;
using CarDealer.DTO.ImportDto;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            CreateMap<CarImportDto, Car>();

            CreateMap<Customer, CustomerExportDto>()
                .ForMember(cdto => cdto.BirthDate, x => x.MapFrom(
                    c => c.BirthDate.ToString("dd/MM/yyyy")));

            CreateMap<Car, CarExportDto>();

            CreateMap<Sale, SaleExportDto>()
                .ForMember(d => d.Discount,
                    mo => mo.MapFrom(
                        s => s.Discount.ToString("f2")))
                .ForMember(
                    d => d.Price,
                    mo => mo.MapFrom(
                        s => s.Car.PartCars.Sum(p => p.Part.Price).ToString("f2")));
        }
    }
}
