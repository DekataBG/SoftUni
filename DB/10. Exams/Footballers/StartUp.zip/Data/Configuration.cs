﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-0EAAFNQ\SQLEXPRESS;Database=Footballers;Trusted_Connection=True";
    }
}
