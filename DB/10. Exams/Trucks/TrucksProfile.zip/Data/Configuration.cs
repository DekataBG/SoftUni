﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-0EAAFNQ\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}