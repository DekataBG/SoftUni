﻿namespace Formula1.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
